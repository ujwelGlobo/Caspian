import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { RouterProvider } from "react-router-dom";
import { QueryClientProvider, QueryClient } from "@tanstack/react-query";

import { router } from "./routes/AppRoutes";
import "./styles/globals.css";

const queryClient = new QueryClient(); // ✅ create instance

createRoot(document.getElementById("root")!).render( <StrictMode> <QueryClientProvider client={queryClient}> <RouterProvider router={router} /> </QueryClientProvider> </StrictMode>
);
